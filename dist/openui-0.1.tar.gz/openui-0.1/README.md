# openUI

https://openui.newkini-dev.com

## 사용법
### 1. openUI를 import합니다.
```python
import openUI
```
